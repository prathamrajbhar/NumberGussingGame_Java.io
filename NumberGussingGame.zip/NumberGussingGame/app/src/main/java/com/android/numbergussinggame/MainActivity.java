package com.android.numbergussinggame;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private EditText editText;
    private TextView textView3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button =findViewById(R.id.button);
        editText =findViewById(R.id.editText);
        textView3 = findViewById(R.id.textView3);
        final int[] random = {(int) (Math.random() * 100) + 1};
        final int[][] chance = {{0}};
        button.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                String s =editText.getText().toString();
                if (random[0] > 85){
                    random[0] = random[0] - 25;
                }
                else if (random[0] < 15){
                    random[0] = random[0] + 25;
                }
                System.out.println(random);
                int UserValue =Integer.parseInt(s);
                if (UserValue == random[0]){
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(1000);
                    textView3.setText("You Are Correct :) ");
                    textView3.setTextColor(R.color.green);
                    System.out.println("Your Chance is : "+chance);
                    Toast.makeText(MainActivity.this, "You Are Correct :) : "+ random[0], Toast.LENGTH_SHORT).show();

                }
                else if(UserValue > random[0]){
                    textView3.setText("You Are Greater :) ");

                    Toast.makeText(MainActivity.this, "Your Value is Greater.", Toast.LENGTH_SHORT).show();
                }
                else if(UserValue < random[0]){
                    textView3.setText("You Are Lower :) ");
                    Toast.makeText(MainActivity.this, "Your Value is Lower.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}